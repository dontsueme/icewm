#ifndef __YKEY_H
#define __YKEY_H

#include "ylib.h"

#include <X11/keysym.h>

#endif
