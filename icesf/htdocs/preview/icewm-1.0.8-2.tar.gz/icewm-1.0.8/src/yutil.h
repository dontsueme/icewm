#ifndef __YUTIL_H
#define __YUTIL_H

#include "ylib.h"

#define __YIMP_XUTIL__

#include <X11/Xutil.h>

#endif
